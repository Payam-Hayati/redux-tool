export const UsersData = [
  {
    id: 1,
    name: "Leanne Graham",
    username: "Bret",
  },
  {
    id: 2,
    name: "Ervin Howell",
    username: "Antonette",
  },
  {
    id: 3,
    name: "Clementine Bauch",
    username: "clementine",
  },
  {
    id: 4,
    name: "Patricia Lebsack",
    username: "Karianne",
  },
];
